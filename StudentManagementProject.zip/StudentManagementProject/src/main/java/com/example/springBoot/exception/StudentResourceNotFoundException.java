package com.example.springBoot.exception;

public class StudentResourceNotFoundException extends RuntimeException {

	public StudentResourceNotFoundException(Long id) {
		super("could not found the user with id "+id);
	}
}
