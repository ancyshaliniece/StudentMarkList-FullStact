package com.example.springBoot.repository;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.springBoot.services.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {

	List<Student> findAll(Specification<Student> filterDetails);

}
