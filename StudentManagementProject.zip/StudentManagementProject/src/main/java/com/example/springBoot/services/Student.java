package com.example.springBoot.services;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="student")
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name="StudentName")
	private String studentName;
	
	@Column(name="studentEmailId")
	private String studentEmailId;
	
	@Column(name="studentGender")
	private String studentGender;
	
	@Column(name="studentStd")
	private String studentStd;
	
	@Column(name="tamil")
	private int tamil;
	
	@Column(name="english")
	private int english;
	
	@Column(name="maths")
	private int maths;
	
	@Column(name="science")
	private int science;
	
	@Column(name="social")
	private int social;
	
	@Column(name="total")
	private int total;
	
	@Column(name="average")
	private float average;
	
	@Column(name="grade")
	private String grade;
	
	
	public Student(long id, String studentName, String studentEmailId, String studentGender, String studentStd,
			int tamil, int english, int maths, int science, int social, int total, float average, String grade) {
		super();
		this.id = id;
		this.studentName = studentName;
		this.studentEmailId = studentEmailId;
		this.studentGender = studentGender;
		this.studentStd = studentStd;
		this.tamil = tamil;
		this.english = english;
		this.maths = maths;
		this.science = science;
		this.social = social;
		this.total = total;
		this.average = average;
		this.grade = grade;
	}
	public Student() {
	}
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentEmailId() {
		return studentEmailId;
	}
	public void setStudentEmailId(String studentEmailId) {
		this.studentEmailId = studentEmailId;
	}
	public String getStudentGender() {
		return studentGender;
	}
	public void setStudentGender(String studentGender) {
		this.studentGender = studentGender;
	}
	public String getStudentStd() {
		return studentStd;
	}
	public void setStudentStd(String studentStd) {
		this.studentStd = studentStd;
	}
	public int getTamil() {
		return tamil;
	}
	public void setTamil(int tamil) {
		this.tamil = tamil;
	}
	public int getEnglish() {
		return english;
	}
	public void setEnglish(int english) {
		this.english = english;
	}
	public int getMaths() {
		return maths;
	}
	public void setMaths(int maths) {
		this.maths = maths;
	}
	public int getScience() {
		return science;
	}
	public void setScience(int science) {
		this.science = science;
	}
	public int getSocial() {
		return social;
	}
	public void setSocial(int social) {
		this.social = social;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public float getAverage() {
		return average;
	}
	public void setAverage(float average) {
		this.average = average;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	
	
	
	
	
	
	
}
