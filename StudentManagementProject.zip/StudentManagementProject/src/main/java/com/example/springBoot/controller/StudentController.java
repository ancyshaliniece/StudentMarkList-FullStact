package com.example.springBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.springBoot.exception.StudentResourceNotFoundException;
import com.example.springBoot.repository.StudentRepository;
import com.example.springBoot.services.Student;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/dewsSchool")
public class StudentController {
	
	@Autowired
	private StudentRepository studentRepository;
	
	@PostMapping("/addNew_Student_Details")
	public Student addNewStudent(@RequestBody Student newStudent) {
		return studentRepository.save(newStudent);
	}
	
	@GetMapping("/get_AllStudents_details")
	public List<Student> getAllStudentDetails(){
		return studentRepository.findAll();
	}
	@GetMapping("/get_AllStudent_detail/{id}")
	public Student getSingleStudentDetail(@PathVariable Long id){
		return studentRepository.findById(id).orElseThrow(()->new StudentResourceNotFoundException(id));
	}
	//sorting
	@GetMapping("/sortStudents")
	public List<Student> sortStudentList(
			@RequestParam(name = "field", required = true) String field,
			@RequestParam(name = "direction", required = false, defaultValue = "asc") String direction){
		
		Sort.Direction sorting = Sort.Direction.ASC;
		 if("desc".equalsIgnoreCase(direction)) {
			 sorting = Sort.Direction.DESC;
		 }
		 
		 return studentRepository.findAll(Sort.by(sorting, field));
	}
	
	//Pagination
	@GetMapping("/pagination")
	public Page<Student> paginationForStudentList(
			@RequestParam(name = "offset",required = false, defaultValue = "0") Integer offset,
			@RequestParam(name = "pageSize", required = true) Integer pageSize){
		Pageable pageable = PageRequest.of(offset, pageSize);

	    return studentRepository.findAll(pageable);
		
	}
		
	@PutMapping("/updateStudentDetaild/{id}")
	public Student updateStudentDetails(@RequestBody Student updateStudent,@PathVariable Long id) {
		return studentRepository.findById(id).map(studentData->{
			studentData.setStudentName(updateStudent.getStudentName());
			studentData.setStudentEmailId(updateStudent.getStudentEmailId());
			studentData.setStudentGender(updateStudent.getStudentGender());
			studentData.setStudentStd(updateStudent.getStudentStd());
//			studentData.setId(updateStudent.getId());
			studentData.setTamil(updateStudent.getTamil());
			studentData.setEnglish(updateStudent.getEnglish());
			studentData.setMaths(updateStudent.getMaths());
			studentData.setScience(updateStudent.getScience());
			studentData.setSocial(updateStudent.getSocial());
			studentData.setTotal(updateStudent.getTotal());
			studentData.setAverage(updateStudent.getAverage());
			studentData.setGrade(updateStudent.getGrade());
			return studentRepository.save(studentData);
		}
		).orElseThrow(()-> new StudentResourceNotFoundException(id));
	}
	
	@DeleteMapping("/deleteStudent/{id}")
	public String deleteStudentDetails(@PathVariable Long id) {
		
		 if(!studentRepository.existsById(id)) {
			throw new StudentResourceNotFoundException(id);
		}
		 studentRepository.deleteById(id);
		 
		return "User with id "+id+" has been deleted SuccessFully";
	}
	
	@GetMapping("/filter")
	public List<Student> filterStudentDetails(
			@RequestParam (name = "studentName", required = false) String studentName,
			@RequestParam (name = "studentGender", required = false) String studentGender,
			@RequestParam (name = "id", required = false) Integer studentId){
		
		Specification<Student> filterDetails = Specification.where(null);
		
		if(studentName!=null) {
			filterDetails = filterDetails.and((root,query,criteriaBuilder)->
			criteriaBuilder.like(root.get("studentName"), studentName));
		}
		
		if(studentGender!=null) {
			filterDetails = filterDetails.and((root,query,criteriaBuilder)->
			criteriaBuilder.like(root.get("studentGender"), studentGender));
		}
		
		if(studentId != null) {
			filterDetails = filterDetails.and((root,query,criteriaBuilder)->
			criteriaBuilder.equal(root.get("id"),studentId));
		}
		
		return studentRepository.findAll(filterDetails);
		
	}
	
	
	
//	 @GetMapping("/search-by-substring")
//	    public List<Student> searchStudentsBySubstring(@RequestParam(name = "studentName") String substring) {
//		 
//	        return studentRepository.findByNameContaining(substring);
//	    }
	
	
	

}
